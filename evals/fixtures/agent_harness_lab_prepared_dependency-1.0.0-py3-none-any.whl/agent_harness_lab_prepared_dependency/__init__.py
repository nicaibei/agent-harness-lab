def readiness_message() -> str:
    return 'dependency-ready'
