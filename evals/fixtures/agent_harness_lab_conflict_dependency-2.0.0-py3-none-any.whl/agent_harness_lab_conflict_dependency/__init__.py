__version__ = '2.0.0'

def readiness_message() -> str:
    return 'dependency-v2-ready'
